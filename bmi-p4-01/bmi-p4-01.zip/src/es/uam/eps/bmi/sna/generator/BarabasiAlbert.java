package es.uam.eps.bmi.sna.generator;

public class BarabasiAlbert {

}
